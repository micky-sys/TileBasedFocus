/******************************************************************************
 * (c) 2017 by SICK AG
 * Project: GenApi
 * Authors: Joakim Akerblom
 * $Header$
 *
 * License: This file is published under the license of the EMVA GenICam  Standard Group.
 * A text file describing the legal terms is included in your installation as 'GenICam_license.pdf'.
 * If for some reason you are missing  this file please contact the EMVA or visit the website
 * (http://www.genicam.org) for a full copy.
 *
 * THIS SOFTWARE IS PROVIDED BY THE EMVA GENICAM STANDARD GROUP "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE EMVA GENICAM STANDARD  GROUP
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,  SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT  LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,  DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY  THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT  (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE  OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

package org.genicam.genapi;

import java.lang.ref.WeakReference;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

/**
 * <p>
 * A garbage collection guard solves the problem GC is called at the same time
 * on an entire isolated island of object instances that need to be destructed
 * in a particular order (in C++). There is no guarantee that instances that are
 * finalized in the the same GC cycle (in Java) will be finalized in any
 * particular order, hence the destructors (in C++) will be called in arbitrary
 * order.
 * </p>
 * <p>
 * Garbage collection guard solves this problem by keeping a strong reference
 * (in Java) to the instance to be destructed last (in C++) until the the
 * instance to be destructed first (in C++) do not exist any more (in Java).
 * </p>
 * 
 * @author Joakim Akerblom
 *
 */
public class GarbageCollectGuard
{
    private static final GarbageCollectorHook HOOK = new GarbageCollectorHook();
    private static IGarbageCollectGuard guard = new BasicGarbageCollectGuard();

    static
    {
        HOOK.setAction(new Runnable()
        {
            @Override
            public void run()
            {
                guard.pruneRelations();
            }
        });
        HOOK.placeBait();
    }

    /** The used guard instance. */
    public static IGarbageCollectGuard guard()
    {
        return guard;
    }

    /** Set guard. Useful for testing purposes. */
    public static void guard(IGarbageCollectGuard g)
    {
        guard = g;
    }

    /** The used garbage collection hook instance. */
    public static GarbageCollectorHook hook()
    {
        return HOOK;
    }

    /** @see IGarbageCollectGuard#addRelation(Object, Object) */
    public static void addRelation(Object deleteFirst, Object deleteLast)
    {
        guard.addRelation(deleteFirst, deleteLast);
    }

    /** @see IGarbageCollectGuard#removeRelation(Object) */
    public static void removeRelation(Object deleteFirst, Object deleteLast)
    {
        guard.removeRelation(deleteFirst, deleteLast);
    }

    /** @see IGarbageCollectGuard#removeRelationsWaitingFor(Object) */
    public static void removeRelationsWaitingFor(Object deleteFirst)
    {
        guard.removeRelationsWaitingFor(deleteFirst);
    }

    public interface IGarbageCollectGuard
    {
        /** Add delete order relation */
        void addRelation(Object deleteFirst, Object deleteLast);

        /**
         * Remove fulfilled relations and return the secondary objects in pruned
         * relation pairs
         */
        void pruneRelations();

        /** Remove relation if found and not already fulfilled. */
        void removeRelation(Object deleteFirst, Object deleteLast);

        /**
         * Remove all relations waiting for argument to be deleted first, if
         * found and not already fulfilled.
         */
        void removeRelationsWaitingFor(Object deleteFirst);

        /**
         * Get the number of delete relations waiting to be fulfilled, including
         * fulfilled relation not pruned.
         */
        int getRelationCount();
    }

    /** A relation between between two objects to be garbage collected. */
    static class Relation
    {
        // A weak reference to an object allows the garbage collector to clean
        // up the object in question, even though there is a reference to it.
        // The weak reference enables us to query if the object exists or is
        // garbage collected.
        WeakReference<Object> mFirst;

        // Keep reference as long as needed for mPrimary to be garbage collected
        // first.
        @SuppressWarnings("unused")
        Object mLast;

        Relation(Object first, Object last)
        {
            mFirst = new WeakReference<Object>(first);
            mLast = last;
        }

        public boolean isPruneable()
        {
            // This method returns null, if this reference object has been
            // cleared by GC.
            return mFirst.get() == null;
        }
    }

    static class BasicGarbageCollectGuard implements IGarbageCollectGuard
    {
        List<Relation> mRecord = new LinkedList<Relation>();

        @Override
        public void addRelation(Object deleteFirst, Object deleteLast)
        {
            mRecord.add(new Relation(deleteFirst, deleteLast));
        }

        @Override
        public void pruneRelations()
        {
            pruneRelations(mRecord);
        }

        void pruneRelations(List<Relation> record)
        {
            ListIterator<Relation> it = record.listIterator();

            while (it.hasNext())
            {
                if (it.next().isPruneable())
                {
                    it.remove();
                }
            }
        }

        @Override
        public void removeRelation(Object deleteFirst, Object deleteLast)
        {
            ListIterator<Relation> it = mRecord.listIterator();

            while (it.hasNext())
            {
                Relation rel = it.next();
                if (rel.mLast == deleteLast && rel.mFirst.get() == deleteFirst)
                {
                    it.remove();
                }
            }
        }

        @Override
        public int getRelationCount()
        {
            return mRecord.size();
        }

        @Override
        public void removeRelationsWaitingFor(Object deleteFirst)
        {
            ListIterator<Relation> it = mRecord.listIterator();

            while (it.hasNext())
            {
                Relation rel = it.next();
                if (rel.mFirst.get() == deleteFirst)
                {
                    it.remove();
                }
            }
        }
    }

    /**
     * Listens in on calls to finalize to trigger an action in roughly the same
     * pace as the java virtual machine garbage collector is run.
     */
    public static class GarbageCollectorHook
    {
        private Runnable action;

        public void setAction(Runnable onGarbageCollectionAction)
        {
            action = onGarbageCollectionAction;
        }

        public Runnable getAction()
        {
            return action;
        }

        /**
         * <p>
         * Places a bait for the garbage collector to clean up. The bait is an
         * object instance without any strong references to it, so it will
         * sooner or later be garbage collected.
         * </p>
         * <p>
         * <b>N.B.</b> On bait finalization, a new bait is placed. This creates
         * an infinite loop calling the currently specified action each time the
         * garbage collector takes the bait.
         * </p>
         */
        public void placeBait()
        {
            new Object()
            {
                @Override
                protected void finalize() throws Throwable
                {
                    if (action != null)
                    {
                        action.run();
                    }
                    placeBait();
                    super.finalize();
                }
            };
        }
    }
}
