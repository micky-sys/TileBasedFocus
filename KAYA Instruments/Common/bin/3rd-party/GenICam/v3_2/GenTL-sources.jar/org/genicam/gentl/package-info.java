/**
 * This package contains classes to load and use a GenTL Producer from Java.
 * <p>
 * <pre>{@code
 * try
 * {
 *     System.loadLibrary("GenTLJava_MDd_VC100_v3_0");
 *     System.loadLibrary("GenApiJava_MDd_VC100_v3_0");
 * }
 * catch (UnsatisfiedLinkError e)
 * {
 *     throw new RuntimeException("Native code library failed to load. ", e);
 * }
 *
 * GenTLProducer producer = GenTLProducer.load("path/to/my/producer.cti");
 * TransportLayer tl = producer.openTransportLayer();
 *
 * // Open first interface
 * tl.updateInterfacesList(100);
 * List<InterfaceInfo> ifaces = tl.getInterfaces();
 * TLInterface interfaceA = ifaces.get(0).open();
 *
 * // Open first found device
 * interfaceA.updateDeviceList(1000);
 * DeviceInfo deviceInfo = interfaceA.getDeviceList().get(0);
 * Device device = deviceInfo.open(DeviceAccessFlags.DEVICE_ACCESS_EXCLUSIVE);
 *
 * // Read 4 bytes from device at address 0x104
 * Port remotePort = device.getRemotePort();
 * ByteBuffer buffer = ByteBuffer.allocateDirect(4);
 * remotePort.read(0x104, buffer);
 *
 * }</pre>
 *
 * Example to initiate data streaming. This assumes that a GenApi nodeMap is
 * already setup and connected to the device Port.
 *
 * <pre>{@code
 * // Open data stream
 * List<String> dataStreamIDs = device.getDataStreamIDs();
 * DataStream ds = device.openDataStream(dataStreamIDs.get(0));
 *
 * ByteBuffer data = ByteBuffer.allocateDirect(1024 * 1024);
 * UserData userData = new UserData(7);
 * Buffer buffer = ds.announceBuffer(data, userData);
 * ds.queueBuffer(buffer);
 *
 * NewBufferEvent event = ds.registerNewBufferEvent();
 *
 * GCError status = ds.startAcquisition(AcqStartFlags.ACQ_START_FLAGS_DEFAULT, 1);
 *
 * // Tell device to start via GenApi
 * nodeMap.getCommandNode("AcquisitionStart").execute();
 *
 * NewBufferEventData eventData = event.getData(1000);
 * // Now there should be data in the ByteBuffer :)
 *
 * ds.flushQueue(AcqQueueType.ACQ_QUEUE_ALL_DISCARD);
 * ds.stopAcquisition(AcqStopFlags.ACQ_STOP_FLAGS_KILL);
 * ds.revokeBuffer(buffer);
 *
 * }</pre>
 */
package org.genicam.gentl;